#******************************************************************************************************************
#***************  MODULE 2 CONTAINING TESTING ALGORITHMS ********************************************************
#******************************************************************************************************************

from django.shortcuts import render_to_response
from django.shortcuts import render
from distutils.dir_util import copy_tree



import os
import errno
import shutil


# ***  Creates a directory npath and gives full permissions ****
def create_directory(dpath):
	#try:
	#npath = r'static/BRANDON_TEST'
	mode = 0777 
	npath = r'static/' + dpath
	os.makedirs(npath)
	os.chmod(npath,mode)
	#except OSError as exception:
	#	if exception.errno !- errno.EEXIST:
	#		raise		
	return 

def delete_directory(dpath):
	
	npath = r'static/' + dpath
	try:
		shutil.rmtree(npath)
	except:
		dum = 1
	return 
	
# *** Will copy files from one directory to another ***	
def copy_directory(to_Directory,from_Template):

	# **** Copies selected file to destination directory **
	#f='static/images/button_adduser.gif'
	#d='static/BRANDON_TEST'
	#shutil.copy(f,d)
	
	# ***  Copy entire directory to another *****
	to_Directory = 'static/' + to_Directory
	from_Directory = "static/wec/template_files/" + from_Template 


	copy_tree(from_Directory, to_Directory)
	
	
	
	return	

def path_local():
	path_local = 'static/wec/wec_company'
#	path_local = 'firstsite/wec/static/wec/wec_company'
	return path_local
